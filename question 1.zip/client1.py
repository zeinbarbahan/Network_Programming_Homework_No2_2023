import socket
import json

cs = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
cs.settimeout(5)

try:
    cs.connect(('127.0.0.1', 8585))
    num_questions = int(cs.recv(1024).decode())
    for i in range(num_questions):
        question = cs.recv(1024).decode()
        answer = input(f"{question}: ")
        cs.sendall(answer.encode())
except socket.error as err_msg:
    print(err_msg)
final_score = cs.recv(1024).decode()
print(f"Final score: {final_score}")

