import socket,threading
import json

questions = {
    "what is the answer of 3*3":"9",
    "what is the answer of 3*5":"15",
    "what is the answer of 3+3 ":"6",
    "what is the answer of 31-3 ":"29",
    "what is the answer of 3-3 ":"0",
    "what is the answer of 3**3 ":"27",
    "what is the answer of 4*5 ":"20",
    "what is the answer of 9*9 ":"81",
    "what is the answer of 4+4 ":"8",
    "what is the answer of 5*5 ":"25",
    "what is the answer of 3+13 ": "16",
    "what is the answer of 2+5 ":"7",
    "what is the answer of 8+3 ":"11",
    "what is the answer of 3*7 ":"21",
    "what is the answer of 3*4":"12",
    "what is the answer of 3*8 ":"24",
    "what is the answer of 5*6 ":"30",
    "what is the answer of 3-2 ":"1",
    "what is the answer of 3+61":"64",
    "what is the answer of 5+9 ":"14"}

result = {}

def handle_request(cs, cadd):
    cs.send(str(len(questions)).encode())
    for question in questions:
        cs.send(question.encode())
        client_ans = cs.recv(10).decode().strip()
        if client_ans.upper() == questions[question].upper():
            result[cadd] = result.get(cadd, 0) + 1
    score = result.get(cadd, 0)
    cs.send(f"Score: {score}/{len(questions)}\n".encode())
    cs.close()

class handle_client_thread(threading.Thread):
    def __init__(self,cs,cadd):
        threading.Thread.__init__(self)
        self.cs=cs
        self.cadd=cadd

    def run(self):
        handle_request(self.cs,self.cadd)

ss = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
try:
    ss.bind(('127.0.0.1',8585))
except OSError as err_msg:
    print(err_msg)
ss.listen(5)
print(" Exam Server is Ready and waiting for clients .")
while True:
    cs, cadd = ss.accept()
    print(f"[+] tcp server is waiting for new connection....' {cadd}")
    client = handle_client_thread(cs, cadd)
    client.start()



